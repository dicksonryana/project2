--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Tweets";
--
-- Name: Tweets; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Tweets" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "Tweets" OWNER TO postgres;

\connect "Tweets"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CDC Tweets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CDC Tweets" (
    "Tweet Rank" integer NOT NULL,
    "Tweet ID" character varying(10),
    tweet character varying(500)
);


ALTER TABLE public."CDC Tweets" OWNER TO postgres;

--
-- Name: CDC Tweets_Tweet Rank_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CDC Tweets_Tweet Rank_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CDC Tweets_Tweet Rank_seq" OWNER TO postgres;

--
-- Name: CDC Tweets_Tweet Rank_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CDC Tweets_Tweet Rank_seq" OWNED BY public."CDC Tweets"."Tweet Rank";


--
-- Name: NRA Tweets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NRA Tweets" (
    "Tweet Rank" integer NOT NULL,
    "Tweet ID" character varying(10),
    tweet character varying(500)
);


ALTER TABLE public."NRA Tweets" OWNER TO postgres;

--
-- Name: NRA Tweets_Tweet Rank_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NRA Tweets_Tweet Rank_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."NRA Tweets_Tweet Rank_seq" OWNER TO postgres;

--
-- Name: NRA Tweets_Tweet Rank_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NRA Tweets_Tweet Rank_seq" OWNED BY public."NRA Tweets"."Tweet Rank";


--
-- Name: Netflix Tweets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Netflix Tweets" (
    "Tweet Rank" integer NOT NULL,
    "Tweet ID" character varying(10),
    tweet character varying(500)
);


ALTER TABLE public."Netflix Tweets" OWNER TO postgres;

--
-- Name: Netflix Tweets_Tweet Rank_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Netflix Tweets_Tweet Rank_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Netflix Tweets_Tweet Rank_seq" OWNER TO postgres;

--
-- Name: Netflix Tweets_Tweet Rank_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Netflix Tweets_Tweet Rank_seq" OWNED BY public."Netflix Tweets"."Tweet Rank";


--
-- Name: Tweet Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tweet Category" (
    "Tweet ID" character varying(10),
    "Tweet Category" character varying(30)
);


ALTER TABLE public."Tweet Category" OWNER TO postgres;

--
-- Name: CDC Tweets Tweet Rank; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CDC Tweets" ALTER COLUMN "Tweet Rank" SET DEFAULT nextval('public."CDC Tweets_Tweet Rank_seq"'::regclass);


--
-- Name: NRA Tweets Tweet Rank; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NRA Tweets" ALTER COLUMN "Tweet Rank" SET DEFAULT nextval('public."NRA Tweets_Tweet Rank_seq"'::regclass);


--
-- Name: Netflix Tweets Tweet Rank; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Netflix Tweets" ALTER COLUMN "Tweet Rank" SET DEFAULT nextval('public."Netflix Tweets_Tweet Rank_seq"'::regclass);


--
-- Data for Name: CDC Tweets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CDC Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM stdin;
\.
COPY public."CDC Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM '$$PATH$$/2847.dat';

--
-- Data for Name: NRA Tweets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NRA Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM stdin;
\.
COPY public."NRA Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: Netflix Tweets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Netflix Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM stdin;
\.
COPY public."Netflix Tweets" ("Tweet Rank", "Tweet ID", tweet) FROM '$$PATH$$/2843.dat';

--
-- Data for Name: Tweet Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tweet Category" ("Tweet ID", "Tweet Category") FROM stdin;
\.
COPY public."Tweet Category" ("Tweet ID", "Tweet Category") FROM '$$PATH$$/2841.dat';

--
-- Name: CDC Tweets_Tweet Rank_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CDC Tweets_Tweet Rank_seq"', 20, true);


--
-- Name: NRA Tweets_Tweet Rank_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NRA Tweets_Tweet Rank_seq"', 21, true);


--
-- Name: Netflix Tweets_Tweet Rank_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Netflix Tweets_Tweet Rank_seq"', 20, true);


--
-- Name: CDC Tweets CDC Tweets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CDC Tweets"
    ADD CONSTRAINT "CDC Tweets_pkey" PRIMARY KEY ("Tweet Rank");


--
-- Name: NRA Tweets NRA Tweets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NRA Tweets"
    ADD CONSTRAINT "NRA Tweets_pkey" PRIMARY KEY ("Tweet Rank");


--
-- Name: Netflix Tweets Netflix Tweets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Netflix Tweets"
    ADD CONSTRAINT "Netflix Tweets_pkey" PRIMARY KEY ("Tweet Rank");


--
-- PostgreSQL database dump complete
--

